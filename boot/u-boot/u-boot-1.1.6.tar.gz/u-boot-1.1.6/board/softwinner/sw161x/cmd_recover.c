
#include <common.h>
#include <command.h>
#include <linux/ctype.h>

extern void jump_to(unsigned int addr);

int do_recover (cmd_tbl_t *cmdtp, int flag, int argc, char *argv[])
{
	printf("\nStart to recover...\n\n\n\n");
	jump_to(FEL_BASE);
}

/* ====================================================================== */
U_BOOT_CMD(
	recover,      1,      0,      do_recover,
	"recover - set the machine status to usb recovering.\n",
	" [address] - jumt to fel.\n"
);

