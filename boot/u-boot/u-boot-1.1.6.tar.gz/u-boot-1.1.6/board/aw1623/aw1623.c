/*
*********************************************************************************************************
*                                                    U-BOOT
*                                    the Easy Portable/Player Develop Kits
*                                                 Board Module
*
*                                    (c) Copyright 2006-2011, kevin.z China
*                                             All Rights Reserved
*
* File    : aw1623.c
* By      : kevin.z
* Version : v1.0
* Date    : 2011-4-6 12:48
* Descript: board initialise.
* Update  : date                auther      ver     notes
*********************************************************************************************************
*/

#include <common.h>
#include <asm/arch/sys_proto.h>

DECLARE_GLOBAL_DATA_PTR;

/*
 * Dummy functions to handle errors for EABI incompatibility
 */
void raise(void)
{
}

void abort(void)
{
}


/**********************************************************
 * Routine: s_init
 * Description: Does early system init of muxing and clocks.
 * - Called path is with SRAM stack.
 **********************************************************/
void s_init(void)
{
    /* flush d-cache and i-cache    */
	v7_flush_dcache_all(0);
    /* enable icache    */
	icache_enable();
	/* enable L2 cache  */
	l2cache_enable();
}




void ether__init (void);

static inline void delay (unsigned long loops)
{
	__asm__ volatile ("1:\n"
			  "subs %0, %1, #1\n"
			  "bne 1b":"=r" (loops):"0" (loops));
}

/*
 * Miscellaneous platform dependent initialisations
 */

int board_init (void)
{
	/* arch number of OMAP 730 P2 Board - Same as the Innovator! */
	gd->bd->bi_arch_number = MACH_TYPE_SOFTWINNER;

	/* adress of boot parameters */
	gd->bd->bi_boot_params = 0x40000100;

	return 0;
}

int misc_init_r(void)
{
   return 0;
}

/*************************************************************
 Routine:ether__init
 Description: take the Ethernet controller out of reset and wait
			   for the EEPROM load to complete.
*************************************************************/
void ether__init (void)
{

}

/******************************
 Routine:
 Description:
******************************/
int dram_init (void)
{
	gd->bd->bi_dram[0].start = PHYS_SDRAM_1;
	gd->bd->bi_dram[0].size = PHYS_SDRAM_1_SIZE;

	return 0;
}

