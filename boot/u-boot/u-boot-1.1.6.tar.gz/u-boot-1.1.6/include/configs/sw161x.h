/*
 * (C) Copyright 2003-2004
 * MPC Data Limited (http://www.mpc-data.co.uk)
 * Dave Peverley <dpeverley at mpc-data.co.uk>
 *
 * Configuation settings for the TI OMAP Perseus 2 board.
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.		See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#ifndef __CONFIG_H
#define __CONFIG_H

#include <asm/arch/hardware.h>

/*
 * The ADS GCPlus Linux boot ROM loads U-Boot into RAM at 0xc0200000.
 * We don't actually init RAM in this case since we're using U-Boot as
 * an secondary boot loader during Linux kernel development and testing,
 * e.g. bootp/tftp download of the kernel is a far more convenient
 * when testing new kernels on this target. However the ADS GCPlus Linux
 * boot ROM leaves the MMU enabled when it passes control to U-Boot. So
 * we use lowlevel_init (CONFIG_INIT_CRITICAL) to remedy that problem.
 */
#define  CONFIG_SKIP_LOWLEVEL_INIT  1
//#define CONFIG_SKIP_RELOCATE_UBOOT	1

/* allow to overwrite serial and ethaddr */
#define CONFIG_ENV_OVERWRITE

/*
 * High Level Configuration Options
 * (easy to change)
 */

#define CONFIG_ARM926EJS	   1	     /* This is an arm926ejs CPU core  */
#define CONFIG_SW1651X		   1	     /* in a SOFTWINNER core    */

#undef CONFIG_USE_IRQ			     /* we don't need IRQ/FIQ stuff */

#define CONFIG_CMDLINE_TAG	   1	     /* enable passing of ATAGs	 */
#define CONFIG_SETUP_MEMORY_TAGS   1

/*
 * Size of malloc() pool
 */

#define CFG_MALLOC_LEN		   (CFG_ENV_SIZE + 128*1024)
#define CFG_GBL_DATA_SIZE	   128	     /* size in bytes reserved for initial data */

/*
 * Hardware drivers
 */

/*
 * NS16550 Configuration
 */
#define CFG_NS16550
#define CFG_NS16550_SERIAL
#define CFG_NS16550_REG_SIZE	   (4)
#define CFG_NS16550_CLK		   (60000000)	  /* can be 12M/32Khz or 48Mhz */
#define CFG_NS16550_COM1	   UART0_REGS_BASE	  /* uart0 */
#define CFG_NS16550_COM2	   UART1_REGS_BASE	  /* uart1 */
#define CFG_NS16550_COM3	   UART2_REGS_BASE	  /* uart2 */
#define CFG_NS16550_COM4	   UART3_REGS_BASE	  /* uart3 */
						   

/*
 * select serial console configuration
 */
#define CONFIG_AUTOBOOT_PROMPT		"autoboot in %d seconds\n"
#define CONFIG_BOOTDELAY		3
#define CONFIG_SERIAL_MULTI
#define CONFIG_SERIAL1		   1	     /* we use SERIAL 1 on OMAP730 Perseus 2 */
#define CONFIG_CONS_INDEX	   1
#define CFG_CONSOLE_IS_IN_ENV
#define CONFIG_BAUDRATE		   115200
#define CFG_BAUDRATE_TABLE	   { 9600, 19200, 38400, 57600, 115200 }

#define CONFIG_COMMANDS		   (   \
										(CONFIG_CMD_DFL | \
										 CFG_CMD_DHCP  |  \
										 CFG_CMD_PING  \
										 ) \
										 & ~CFG_CMD_IMLS & ~CFG_CMD_FLASH)

/*
 * This must be included AFTER the definition of CONFIG_COMMANDS (if any)
 */

#include <cmd_confdefs.h>

#define CONFIG_LOADADDR		   0x81000000
#define CONFIG_BOOTFILE		   "/uImage"

//#define ET_DEBUG					1
//#define NFS_DEBUG
#define CONFIG_NET_MULTI		1

/*
 * Miscellaneous configurable options
 */

#define CFG_LONGHELP				       /* undef to save memory	   */
#define CFG_PROMPT		   "sw161x# "      /* Monitor Command Prompt   */
#define CFG_CBSIZE		   256		       /* Console I/O Buffer Size  */
/* Print Buffer Size */
#define CFG_PBSIZE		   (CFG_CBSIZE+sizeof(CFG_PROMPT)+16)
#define CFG_MAXARGS		   32		       /* max number of command args   */
#define CFG_BARGSIZE		   CFG_CBSIZE	       /* Boot Argument Buffer Size    */

#define CFG_MEMTEST_START	   0x10000000	       /* memtest works on */
#define CFG_MEMTEST_END		   0x12000000	       /* 32 MB in DRAM	   */

#undef CFG_CLKS_IN_HZ		     /* everything, incl board info, in Hz */

#define CFG_LOAD_ADDR		   0x10000000	       /* default load address */

#define	CFG_HZ							(1000000)

/*-----------------------------------------------------------------------
 * Stack sizes
 *
 * The stack sizes are set up in start.S using the settings below
 */

#define CONFIG_STACKSIZE	   (128*1024)	  /* regular stack */
#ifdef CONFIG_USE_IRQ
#define CONFIG_STACKSIZE_IRQ	   (4*1024)	  /* IRQ stack */
#define CONFIG_STACKSIZE_FIQ	   (4*1024)	  /* FIQ stack */
#endif

/*-----------------------------------------------------------------------
 * Physical Memory Map
 */
#define CFG_NO_FLASH		1		/* There is no FLASH memory	*/

#define CONFIG_NR_DRAM_BANKS	   1		  /* we have 1 bank of DRAM */
#define PHYS_SDRAM_1		   0x10000000	  /* SDRAM Bank #1 */
#define PHYS_SDRAM_1_SIZE	   0x04000000	  /* 32 MB */

#define CFG_ENV_IS_IN_NVRAM
#define CFG_ENV_ADDR		   (0x82a80000)
#define CFG_ENV_SIZE		   0x20000	  /* Total Size of Environment Sector */

#endif	  /* ! __CONFIG_H */
