/*
*********************************************************************************************************
*                                                    MELIS
*                                    the Easy Portable/Player Develop Kits
*                                                 audio Module
*
*                                    (c) Copyright 2006-2011, kevin.z China
*                                             All Rights Reserved
*
* File    : aw1623.h
* By      : kevin.z
* Version : v1.0
* Date    : 2011-4-6 9:56
* Descript: configuration for aw1623 system.
* Update  : date                auther      ver     notes
*********************************************************************************************************
*/
#ifndef __CONFIG_H
#define __CONFIG_H


#include <asm/arch/hardware.h>

/*
 * The ADS GCPlus Linux boot ROM loads U-Boot into RAM at 0xc0200000.
 * We don't actually init RAM in this case since we're using U-Boot as
 * an secondary boot loader during Linux kernel development and testing,
 * e.g. bootp/tftp download of the kernel is a far more convenient
 * when testing new kernels on this target. However the ADS GCPlus Linux
 * boot ROM leaves the MMU enabled when it passes control to U-Boot. So
 * we use lowlevel_init (CONFIG_INIT_CRITICAL) to remedy that problem.
 */
#define  CONFIG_SKIP_LOWLEVEL_INIT      1
//#define CONFIG_SKIP_RELOCATE_UBOOT    1

/* allow to overwrite serial and ethaddr */
#define CONFIG_ENV_OVERWRITE

/*
 * High Level Configuration Options
 * (easy to change)
 */

#define CONFIG_AC328                    1   /* This is an cortext-A8 CPU core  */
#define CONFIG_AW1623                   1   /* in a SOFTWINNER core    */
#undef CONFIG_USE_IRQ                       /* we don't need IRQ/FIQ stuff */
#define CONFIG_CMDLINE_TAG              1   /* enable passing of ATAGs     */
#define CONFIG_SETUP_MEMORY_TAGS        1

/*
 * Size of malloc() pool
 */

#define CFG_MALLOC_LEN                  (CFG_ENV_SIZE + 128*1024)
#define CFG_GBL_DATA_SIZE               128 /* size in bytes reserved for initial data */

/*
 * Hardware drivers
 */


/*
* EMAC driver
*/
#define CONFIG_DRIVER_AWEMAC            1

/*
 * NS16550 Configuration
 */
#define CFG_NS16550
#define AW1623_UART
#define CFG_NS16550_SERIAL
#define CFG_NS16550_REG_SIZE        (4)
#define CFG_NS16550_CLK             (24000000)          /* can be 12M/32Khz or 48Mhz */
#define CFG_NS16550_COM1            UART0_REGS_BASE     /* uart0 */
#define CFG_NS16550_COM2            UART1_REGS_BASE     /* uart1 */
#define CFG_NS16550_COM3            UART2_REGS_BASE     /* uart2 */
#define CFG_NS16550_COM4            UART3_REGS_BASE     /* uart3 */


/*
 * select serial console configuration
 */
#define CONFIG_AUTOBOOT_PROMPT      "autoboot in %d seconds\n"
#define CONFIG_BOOTDELAY            1
#define CONFIG_SERIAL_MULTI
#define CONFIG_SERIAL1              1   /* we use SERIAL 0 on aw1623 */
#define CONFIG_CONS_INDEX           1
#define CFG_CONSOLE_IS_IN_ENV
#define CONFIG_BAUDRATE             115200
#define CFG_BAUDRATE_TABLE          { 9600, 19200, 38400, 57600, 115200 }

#define CONFIG_COMMANDS             (   \
                                        (CONFIG_CMD_DFL | \
                                        CFG_CMD_DHCP  |  \
                                        CFG_CMD_PING  \
                                        ) \
                                        & ~CFG_CMD_IMLS & ~CFG_CMD_FLASH)

/*
 * This must be included AFTER the definition of CONFIG_COMMANDS (if any)
 */

#include <cmd_confdefs.h>

//#define CONFIG_LOADADDR             0x41000000
//#define CONFIG_BOOTFILE             "/uImage"

//#define ET_DEBUG                  1
//#define NFS_DEBUG
#define CONFIG_NET_MULTI            1

/*
 * Miscellaneous configurable options
 */

#define CFG_LONGHELP            /* undef to save memory       */
#define CFG_PROMPT		   "sw1623# "      /* Monitor Command Prompt   */
#define CFG_CBSIZE              256         /* Console I/O Buffer Size  */
/* Print Buffer Size */
#define CFG_PBSIZE              (CFG_CBSIZE+sizeof(CFG_PROMPT)+16)
#define CFG_MAXARGS             32          /* max number of command args   */
#define CFG_BARGSIZE            CFG_CBSIZE  /* Boot Argument Buffer Size    */

#define CFG_MEMTEST_START       0x10000000  /* memtest works on */
#define CFG_MEMTEST_END         0x12000000  /* 32 MB in DRAM       */

#undef  CFG_CLKS_IN_HZ          /* everything, incl board info, in Hz */

#define CFG_LOAD_ADDR           0x4a000000  /* default load address */

/*-----------------------------------------------------------------------
 * Stack sizes
 *
 * The stack sizes are set up in start.S using the settings below
 */

#define CONFIG_STACKSIZE        (128*1024)  /* regular stack */
#ifdef  CONFIG_USE_IRQ
#define CONFIG_STACKSIZE_IRQ    (4*1024)    /* IRQ stack */
#define CONFIG_STACKSIZE_FIQ    (4*1024)    /* FIQ stack */
#endif

/*-----------------------------------------------------------------------
 * Physical Memory Map
 */
#define CFG_NO_FLASH            1           /* There is no FLASH memory    */

#define CONFIG_NR_DRAM_BANKS    1           /* we have 1 bank of DRAM */
#define PHYS_SDRAM_1            0x10000000  /* SDRAM Bank #1 */
#define PHYS_SDRAM_1_SIZE       0x04000000  /* 32 MB */

#define CFG_ENV_IS_NOWHERE
#define CFG_ENV_SIZE            0x2000      /* Total Size of Environment Sector         */

#define CONFIG_EXTRA_ENV_SETTINGS					\
	"nfs_boot=run bootarg;nfs;bootm;echo\0"				\
	"bootarg=setenv bootargs console=${consdev},${consrate} mac_addr=${ethaddr} ${other}\0"	\
	"consdev=ttyS3\0"						\
	"consrate=115200\0"					\
	"stdin=eserial3\0"					\
	"stdout=eserial3\0"					\
	"stderr=eserial3\0"					\
	"other=\0"							\
	"verify=n\0"                          \
	""
	
#define	CONFIG_BOOTCOMMAND      "run nfs_boot"
#define CONFIG_BOOTFILE "/home/chenlm/aw1623_fpga_0.0/subsystems/boot/eGON/bootfs/linux/uImage"

/*
* EMAC config
*/
#define CONFIG_ETHADDR 3a:9d:33:28:d2:00
#define CONFIG_IPADDR 192.168.3.100
#define CONFIG_SERVERIP 192.168.3.37
#define CONFIG_GATEWAYIP        192.168.1.1
#define CONFIG_NETMASK          255.255.255.0

/* base address for indirect vectors (internal boot mode) */
#define VECTOR_BASE             0x00000000
#define LOW_LEVEL_SRAM_STACK    0x00003FFC

#define CFG_TIMERBASE           TIMER_CTRL_BASE
#define CFG_HZ                  (32000)


#endif                /* __CONFIG_H */
